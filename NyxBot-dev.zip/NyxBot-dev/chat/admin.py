from django.contrib import admin

# Register your models here.
from .models import Conversation, Chat

admin.site.register(Chat)
admin.site.register(Conversation)