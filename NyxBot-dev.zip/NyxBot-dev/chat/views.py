from django.shortcuts import render, redirect, HttpResponse
import google.generativeai as genai # type: ignore
import markdown # type: ignore
from .models import Chat, Conversation
from dotenv import load_dotenv
import os
# Configure the Generative AI API
load_dotenv()
genai.configure(api_key=os.environ.get('API_KEY'))
# Enter your Gemini API Key in above variable (You can get your own Gemini API Key from below URL)
# https://aistudio.google.com/app/apikey

model = genai.GenerativeModel(model_name = 'gemini-1.5-flash',system_instruction=['You\'re a helpful bot that helps people.','If you\'re unsure about anything, just apologize.','If you\'re stuck, just ask.','If you think you don\'t have enough information regarding some topic don\'t frame an answer yourself, rather aplogize.'])
chat = model.start_chat(history=[])

def home(req):
    if req.method == 'GET':
        if req.user.is_authenticated:
            # get conversation_id if present in cookies else create a new conversation_id
            conversation_id = req.session.get('conversation_id') 
            if conversation_id:
                pass
            else :
                conversation = Conversation.objects.create(user=req.user)
                print('New id created')
                conversation_id = conversation.pk
                req.session['conversation_id'] = conversation_id
                return render(req, 'chat/home.html')
            
            conversation = Conversation.objects.get(pk = conversation_id)
            chats = Conversation.objects.filter(pk=conversation.pk).first().chats.all()
            # print(chats)
            context = [chat.to_dict() for chat in chats]

            for ch in context:
                # replace **. with \\.** so that period after bold text is not treated as new line and it's not bold as well
                ch['res'] = ch['res'].replace('**.','\\.**')
                # print(ch)
                # create html from markdown for rendering
                ch['res'] = markdown.markdown((ch['res']))
                # print(ch)

            return render(req, 'chat/home.html', {'context': context})
        else: # user not logged in
            count = req.session.get('count')
            print(count)
            if count:
                if count > 5:
                    context = {'flag' : True}
                else:
                    context = {'flag' : False}
            else:
                context = {'flag' : False}
                req.session['count'] = 1

            print(context)
            return render(req, 'chat/home.html', {'context': context})
            


def form(req):
    if req.method == 'POST':
        # grab user message and conversation_id

        if req.user.is_authenticated:

            message = req.POST['user_message']
            conversation_id = req.session['conversation_id']
            # print(message)
            # get response from Gemini
            response = chat.send_message(message)
            # print(response.text)
            conversation = Conversation.objects.get(pk = conversation_id)
            # store the chat in the database
            Chat.objects.create(prompt=message, res=response.text, conversation=conversation)
        
        else:
            message = req.POST['user_message']
            chat_response = chat.send_message(message)
            data = req.session.get('data')
            response = chat_response.text.replace('**.','\\.**')
            response = markdown.markdown((chat_response.text))

            if data:
                data.append({'prompt':message,'res':response})
            else:
                data = [{'prompt':message,'res':response}]
            req.session['data'] = data
        req.session['count'] = req.session.get('count') + 1
        return redirect('home')
    

def deleteCookie(req):
    # delete cookie
    req.session.flush()
    # return to home page
    return redirect('home')

def test(req):
    print(req.user)
    return HttpResponse('ok')