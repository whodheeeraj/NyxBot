from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone
from django.contrib.auth.models import User

class Conversation(models.Model):
    started_at = models.DateTimeField(default = timezone.now) # datetime field for when the conversation started
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='conversations') # user who started the conversation

class Chat(models.Model):
    prompt = models.TextField() # user's message
    res = models.TextField() # chatbot's response
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='chats') # conversation the chat belongs to
    
    def to_dict(self):
        # returns a dictionary of the chat (for sending to the frontend)
        return {
            'prompt': self.prompt,
            'res': self.res
        }
